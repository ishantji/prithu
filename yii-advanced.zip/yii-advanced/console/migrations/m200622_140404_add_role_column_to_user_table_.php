<?php

use yii\db\Migration;

/**
 * Class m200622_140404_add_role_column_to_user_table_
 */
class m200622_140404_add_role_column_to_user_table_ extends Migration
{
    /**
     * {@inheritdoc}
     */
    /*public function safeUp()
    {

    }*/

    /**
     * {@inheritdoc}
     */
  /*  public function safeDown()
    {
        echo "m200622_140404_add_role_column_to_user_table_ cannot be reverted.\n";

        return false;
    }*/

    
    // Use up()/down() to run migration code without a transaction.
    public function safeUp()
    {
        $this->addColumn('{{%user}}', 'role', $this->integer()->notNull());

    }

    public function safeDown()
    {
        $this->dropColumn('{{%user}}', 'role');
    }
    
}
