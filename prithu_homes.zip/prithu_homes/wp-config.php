<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'prithu_homes' );

/** MySQL database username */
define( 'DB_USER', 'root' );

/** MySQL database password */
define( 'DB_PASSWORD', '' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         '64z;xdN(o,E)iZ]eStb!nzK|Q.<?dyv7kJ6M=JbJ+R,ZFa29/1z^ ZNBoyJie#_J' );
define( 'SECURE_AUTH_KEY',  'yVO,$UWT&`f14G($FFNe>=WQ4uF<lWcQX_Ugr7#aO]@oI{44|p^-7Pb_v+WB1hN,' );
define( 'LOGGED_IN_KEY',    'XXzEWyri0K~={Uy*e/216;[.AH;^;[@~3HR<i>2ZI[;Xhqk7KkI+orQ|Cbcdyv|.' );
define( 'NONCE_KEY',        '}V^,..Gj=yBE!D>p$2,K4q~kap^zdd]d5++^(U#NtA50$+S^cjL-x.lT-#~0%Vt-' );
define( 'AUTH_SALT',        '[g[Zsqywdn7:?WrgfFVN1Py>}>fk(V%k&1X_E~Xhq-@obM>`gOyoiBljN95ti&9s' );
define( 'SECURE_AUTH_SALT', 'Aydcv5Tr6-vPt+bx7>.`W~!P^Z@~9FeKVI2({K~gIAh-. =ldzP:R!(27(Wr$9_6' );
define( 'LOGGED_IN_SALT',   'y&d:zx}&12%My{@S8A0sa|Q)6WQY@Y3/oRA#%%@ROq+{2D_ldFwt=y_leC |9_bI' );
define( 'NONCE_SALT',       'hN1mzggx~Dp!@+[T3&UBho45(^(nx}*Y!MWp2E0mFoUTjf30UZ,MIR|X#0Ki4EMf' );

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'pr_ho_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define( 'WP_DEBUG', false );

/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );
}

/** Sets up WordPress vars and included files. */
require_once( ABSPATH . 'wp-settings.php' );
